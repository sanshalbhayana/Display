package apps;

import java.io.*;

import java.util.*;
import java.util.regex.*;
import java.util.ArrayList;


import structures.Stack;

public class Expression {

	/**
	 * Expression to be evaluated
	 */
	String expr;                
    
	/**
	 * Scalar symbols in the expression 
	 */
	ArrayList<ScalarSymbol> scalars; 
	Stack<Character> operators;
	
	/**
	 * Array symbols in the expression
	 */
	ArrayList<ArraySymbol> arrays;
    
    /**
     * String containing all delimiters (characters other than variables and constants), 
     * to be used with StringTokenizer
     */
    public static final String delims = " \t*+-/()[]";
    
    /**
     * Initializes this Expression object with an input expression. Sets all other
     * fields to null.
     * 
     * @param expr Expression
     */
    public Expression(String expr) {
        this.expr = expr;
    }

    /**
     * Populates the scalars and arrays lists with symbols for scalar and array
     * variables in the expression. For every variable, a SINGLE symbol is created and stored,
     * even if it appears more than once in the expression.
     * At this time, values for all variables are set to
     * zero - they will be loaded from a file in the loadSymbolValues method.
     */
    public void buildSymbols() {
       	String thing;
    	int i=0;
    	scalars = new ArrayList<ScalarSymbol>();
    	arrays = new ArrayList<ArraySymbol>();
    	
    	for (i = 0;i<expr.length();i++){
    		thing = "";
    		if (Character.isLetter(expr.charAt(i))){
    			while (i<expr.length() && Character.isLetter(expr.charAt(i))){
    				thing += expr.charAt(i);
    				i++;
    			}
    			if (i<expr.length() && expr.charAt(i)=='['){
    				ArraySymbol a = new ArraySymbol(thing);
    				arrays.add(a);
    			}
    			else{
    				ScalarSymbol a = new ScalarSymbol(thing);
    				scalars.add(a);
    			}
    		}
    	}
    	
    }//end of method
    
    /**
     * Loads values for symbols in the expression
     * 
     * @param sc Scanner for values input
     * @throws IOException If there is a problem with the input 
     */
    

    public void loadSymbolValues(Scanner sc) 
    throws IOException {
        while (sc.hasNextLine()) {
            StringTokenizer st = new StringTokenizer(sc.nextLine().trim());
            int numTokens = st.countTokens();
            String sym = st.nextToken();
            ScalarSymbol ssymbol = new ScalarSymbol(sym);
            ArraySymbol asymbol = new ArraySymbol(sym);
            int ssi = scalars.indexOf(ssymbol);
            int asi = arrays.indexOf(asymbol);
            if (ssi == -1 && asi == -1) {
            	continue;
            }
            int num = Integer.parseInt(st.nextToken());
            if (numTokens == 2) { // scalar symbol
                scalars.get(ssi).value = num;

            } else { // array symbol
            	asymbol = arrays.get(asi);
            	asymbol.values = new int[num];
                // following are (index,val) pairs
                while (st.hasMoreTokens()) {
                    String tok = st.nextToken();
                    StringTokenizer stt = new StringTokenizer(tok," (,)");
                    int index = Integer.parseInt(stt.nextToken());
                    int val = Integer.parseInt(stt.nextToken());
                    asymbol.values[index] = val;              
                }
            }
        }
    }
    
    
    /**
     * Evaluates the expression, using RECURSION to evaluate subexpressions and to evaluate array 
     * subscript expressions.
     * 
     * @return Result of evaluation
     */

    //d*(c-B[a+CARR[0]-A[1]+b])
    //A[B[CARR[1]*2]]/2
    
    
    public float evaluate() {
    	Stack <Character> operators = new Stack <Character>();
		//items = new ArrayList<T>();

    	//Stack values = new Stack();
    	//Stack operands = new Stack();
    	int a = 0;
    	int x = 0;
    	int thing = 0;
    	int b = 0;
    	int i;
    	int [] arr = new int[0];
    	int y = 0;
    	int j = 0;
    	boolean isLong = true;
    	int k=0;
    	
    		
        	//float res = evaluate(expr);
        	//return res;

 
    	
    	while (x<expr.length()){
    			isLong = true;
	    		if ((expr.charAt(x)=='(')){
	    			a=x;//a IS THE POSITION IN THE STRING OF THE FIRST PARANTHESE
	    			operators.push(expr.charAt(x));
	        		x++;
	
	    		}
	    		else if (expr.charAt(x)==')'){
	    			if (operators.peek()=='('){
	    				operators.pop();
	    				thing = Math.round(evaluate(expr.substring(a+1,x)));
	    				expr = expr.substring(0,a) + thing + expr.substring(x+1);
	    				x=0;
	    			}
	    		}
	    		else if (expr.charAt(x)=='['){
	    			j = x-1;
	    			while (j>0){
		    				if (!Character.isLetter(expr.charAt(j)))
		    					break;
		    				j--;
		    			}

	    				if (!Character.isLetter(expr.charAt(j)))
	    					j++;
	    				
		    			if (j==(x-1)) isLong = false;

		    			///if isLong is true, uses arrayA, else uses one letter arrays
		    			if (isLong == false){
		    				for (i=0;i<arrays.size();i++){
		    					if ((expr.substring(x-1,x)).equals(arrays.get(i).name))
		    				     break;
		    				}
			    			arr = arrays.get(i).values;
		    			}
		    			else{
		    				for (k = 0;k<arrays.size();k++){

					    		if ((expr.substring(j,x)).equals(arrays.get(k).name))
					    			break;
		    				}
			    			arr = arrays.get(k).values;
		    			}
				    	b = x;
				    	operators.push(expr.charAt(x));
		    			x++;
	    		}
	    		else if (expr.charAt(x)==']'){
	    			if (operators.peek() == '['){
	    				operators.pop();
	    				//THE OPERATORS STACK IS EMPTY NOW
	    				thing = Math.round(evaluate(expr.substring(b+1,x)));
	    				thing = arr[thing];	   
	    				if (isLong == false){
	    				expr = expr.substring(0,b-1) + thing + expr.substring(x+1);
	    				}
	    				else{
	    					expr = expr.substring(0,j) + thing + expr.substring(x+1);
	    				}
		    			x = 0;
	    			}
	    		}
	    		
	    		else x++;
	    		System.out.println(x);
	    		System.out.println(expr);
    	 }
    	

	    	return evaluate(expr);
	    	
    	
    	
    	//return 0;
    }//end of method evaluate

    
   // d*(c-B[a+CARR[0]-A[1]+b])
    
    private float evaluate (String expression){
    	int i;
    	int sum=0;
    	int mcount=0;
		char thenum;
		int firstnum=0;
		int secondnum=0;
		int s = 0;
		int placeoffirst = 0;
		int placeofsecond = 0;

    	while (s<expression.length()){  

	    		if ((expression.length()>1)&&(Character.isLetter(expression.charAt(s))&&(s<expression.length()-1)&&(Character.isLetter(expression.charAt(s+1))))){
			    	for (i=0;i<scalars.size();i++){
			        	if ((expression.substring(s,s+4)).equals(scalars.get(i).name))
			        		break;
			        }   
			    	expression = expression.substring(0,s) + (scalars.get(i).value) + expression.substring(s+4);
			    	s =0;
    			}
	    			else if (Character.isLetter(expression.charAt(s))){
			    	for (i=0;i<scalars.size();i++){
			        	if ((expression.substring(s,s+1)).equals(scalars.get(i).name))
			        		break;
			        }   
			    	char[] newstringconversion = expression.toCharArray();
			    	newstringconversion[s] = (char)((scalars.get(i).value)+48);
			    	expression = String.valueOf(newstringconversion);
			    	s = 0;
    			}
    			else s++;
    	 }
    	/////////

    	
	    	while (mcount<expression.length()){
				if ((expression.charAt(0)=='-')&&(mcount==0)) mcount++;
				thenum=expression.charAt(mcount);
						if ((thenum=='/')||(thenum=='*')){

							if ((mcount-2>=0)&&(mcount+2<expression.length())){
								if (Character.isDigit(expression.charAt(mcount-2))){
									firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
									placeoffirst = mcount-2;
								}
								else if ((expression.charAt(mcount-2)=='-')&&(!Character.isDigit(expression.charAt(mcount-3)))){
									
									firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
									placeoffirst = mcount-2;
								}
								else{
									firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
									placeoffirst = mcount-1;
								}
								if(Character.isDigit(expression.charAt(mcount+2))){
									secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+3));
									placeofsecond = mcount+2;
								}
								else if (expression.charAt(mcount+1)=='-'){
									secondnum = 0-Integer.valueOf(expression.substring(mcount+1,mcount+3));
									placeofsecond = mcount+2;
								}
								else{
									secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
									placeofsecond = mcount+1;
								}
						}
						else if ((mcount-2<0)&&(mcount+2<expression.length())){
							//IF ONLY THE SECOND NUMBER IS TWO DIGITS
							firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
							placeoffirst = mcount-1;
							
							if (Character.isDigit(expression.charAt(mcount+2))){
								secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+3));
								placeofsecond = mcount+2;
							} 
							else if (expression.charAt(mcount+1)=='-'){
								secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+3));
								placeofsecond = mcount+2;
							}
							else{
								secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
								placeofsecond = mcount+1;
							}
						}
						else if ((mcount-2>=0)&&(mcount+2>=expression.length())){
							//IF ONLY THE FIRST NUMBER IS TWO DIGITS
							secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
							placeofsecond = mcount+1;
							
							if (Character.isDigit(expression.charAt(mcount-2))){
								firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
								placeoffirst = mcount-2;
							}
							else if (expression.charAt(mcount-2)=='-'){
								firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
								placeoffirst = mcount-2;
								
							}
							else{
								firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
								placeoffirst = mcount-1;
								
							}
						}
						
						else if ((mcount-2<0)&&((mcount+2>=expression.length()||(!Character.isDigit(expression.charAt(mcount+2)))))){
							firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
							placeoffirst = mcount-1;
							secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
							placeofsecond = mcount+1;
						}
					}
					
					if (thenum == '*'){
						sum = firstnum*secondnum;						
						if ((placeofsecond == expression.length()-1)||(placeofsecond == expression.length())){
							expression = expression.substring(0,placeoffirst) + sum;		
						}
						else{ 	
							expression = expression.substring(0,placeoffirst) + sum + expression.substring(placeofsecond+1);
						}
						mcount = 0;
						if ((String.valueOf(sum).length())>2){
							mcount = String.valueOf(sum).length();
						}

					}
					else if ((thenum=='/')){
						sum = firstnum/secondnum;						
						if ((placeofsecond == expression.length()-1)||(placeofsecond == expression.length())){
							expression = expression.substring(0,placeoffirst) + sum;		
						}
						else{ 	
							expression = expression.substring(0,placeoffirst) + sum + expression.substring(placeofsecond+1);
						}
						mcount = 0;
						if ((String.valueOf(sum).length())>2){
							mcount = String.valueOf(sum).length();
						}
					}
					else mcount++;

				
				
			}/////////end of while loop

			///////////
	    	placeoffirst = 0;
	    	placeofsecond = 0;
			mcount = 0;
			sum = 0;
			while (mcount<expression.length()){
				if ((expression.charAt(0)=='-')&&(mcount==0))
				mcount++;
						thenum=expression.charAt(mcount);
						if ((thenum=='+')||(thenum=='-')){
							if ((mcount-2>=0)&&(mcount+2<expression.length())){
									if (Character.isDigit(expression.charAt(mcount-2))){
										firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
										placeoffirst = mcount-2;
									}
									else if (expression.charAt(mcount-2)=='-'){
										firstnum = 0-Integer.valueOf(expression.substring(mcount-2,mcount));
										placeoffirst = mcount-2;
									}
									else{
										firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
										placeoffirst = mcount-1;
									}
									
									if(Character.isDigit(expression.charAt(mcount+2))){
										secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+3));
										placeofsecond = mcount+2;
									}
									else if (expression.charAt(mcount+1)=='-'){
										secondnum = 0-Integer.valueOf(expression.substring(mcount+1,mcount+3));
										placeofsecond = mcount+2;
									}
									else{
										secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
										placeofsecond = mcount+1;
									}
							}
							else if ((mcount-2<0)&&(mcount+2<expression.length())){
								//IF ONLY THE SECOND NUMBER IS TWO DIGITS
								firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
								placeoffirst = mcount-1;
								
								if (Character.isDigit(expression.charAt(mcount+2))){
									secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+3));
									placeofsecond = mcount+2;
								} 
								else if (expression.charAt(mcount+1)=='-'){
									secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+3));
									placeofsecond = mcount+2;
								}
								else{
									secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
									placeofsecond = mcount+1;
								}
							}
							else if ((mcount-2>=0)&&(mcount+2>=expression.length())){
								//IF ONLY THE FIRST NUMBER IS TWO DIGITS
								secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
								placeofsecond = mcount+1;
								
								if (Character.isDigit(expression.charAt(mcount-2))){
									firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
									placeoffirst = mcount-2;
								}
								else if (expression.charAt(mcount-2)=='-'){
									firstnum = Integer.valueOf(expression.substring(mcount-2,mcount));
									placeoffirst = mcount-2;
									
								}
								else{
									firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
									placeoffirst = mcount-1;
									
								}
							}
							
							else if ((mcount-2<0)&&((mcount+2>=expression.length()||(!Character.isDigit(expression.charAt(mcount+2)))))){
								firstnum = Integer.valueOf(expression.substring(mcount-1,mcount));
								placeoffirst = mcount-1;
								secondnum = Integer.valueOf(expression.substring(mcount+1,mcount+2));
								placeofsecond = mcount+1;
							}
						}
					if (thenum == '+'){
							sum = firstnum+secondnum;
							if ((placeofsecond == expression.length()-1)||(placeofsecond == expression.length())){
								expression = expression.substring(0,placeoffirst) + sum;		
							}
							else{ 	
								expression = expression.substring(0,placeoffirst) + sum + expression.substring(placeofsecond+1);
							}
							mcount=0;
							if ((String.valueOf(sum).length())>2){
								mcount = String.valueOf(sum).length();
							}
					}
					else if ((thenum=='-')&&(mcount!=0)){
							sum = firstnum-secondnum;						
							if (expression.charAt(mcount+1)=='-'){//IF THERE ARE TWO NEGATIVE SIGNS--CHANGES TO ADDITION
								expression = expression.substring(0,mcount) + '+'+ expression.substring(mcount+2);
								secondnum = 0-secondnum;
							}
							if ((placeofsecond == expression.length()-1)||(placeofsecond == expression.length())){
								expression = expression.substring(0,placeoffirst) + sum;		
							}
							else{ 	
								expression = expression.substring(0,placeoffirst) + sum + expression.substring(placeofsecond+1);
							}
							mcount = 0;
							if ((String.valueOf(sum).length())>2){
								mcount = String.valueOf(sum).length();
							}
						
					}
					else mcount++;

					if ((expression.charAt(0)=='-')&&(expression.charAt(1)=='-'))
						expression=expression.substring(1);
					

			}////////end of while loop



			if ((expression.charAt(0)=='-')&&(expression.charAt(1)=='-'))
				expression=expression.substring(1);

    	return  Float.valueOf(expression);
    	
    }
    
    
    /**
     * Utility method, prints the symbols in the scalars list
     */
    public void printScalars() {
        for (ScalarSymbol ss: scalars) {
            System.out.println(ss);
        }
    }
    
    /**
     * Utility method, prints the symbols in the arrays list
     */
    public void printArrays() {
    		for (ArraySymbol as: arrays) {
    			System.out.println(as);
    		}
    }

}