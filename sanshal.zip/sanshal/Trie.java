package trie;

import java.util.ArrayList;

/**
 * This class implements a Trie. 
 * 
 * @author Sesh Venugopal
 *
 */
public class Trie {
	
	// prevent instantiation
	private Trie() { }
	
	/**
	 * Builds a trie by inserting all words in the input array, one at a time,
	 * in sequence FROM FIRST TO LAST. (The sequence is IMPORTANT!)
	 * The words in the input array are all lower case.
	 * 
	 * @param allWords Input array of words (lowercase) to be inserted.
	 * @return Root of trie with all words inserted from the input array
	 */
 
	public static TrieNode buildTrie(String[] allWords) {
		/** COMPLETE THIS METHOD **/
		
		// FOLLOWING LINE IS A PLACEHOLDER TO ENSURE COMPILATION
		// MODIFY IT AS NEEDED FOR YOUR IMPLEMENTATION
          TrieNode root ;
      
          root = new TrieNode(null, null, null) ;
      
      	  for (int i=0; i < allWords.length; i++) {
			     buildTrieRecurse(root, allWords[i] ,   allWords, i );   
            //Trie.print(root, allWords);
		   }
      
      
		return root;
	}
	
  
 private static TrieNode buildTrieRecurse(TrieNode  root, String  key, String[] allWords, int indx) {
    
    String prefix  ;
    String j ,  k  ;
    Boolean found=false, loop=true ,sibling=false;
    TrieNode Lroot,prevRoot;
   
 
    prevRoot=root;
    Lroot = root.firstChild;  // start with first child of root
 
    k = key;
   
   while (Lroot !=null ) {
     
        k = key;
        prefix =  allWords[Lroot.substr.wordIndex].substring(Lroot.substr.startIndex, Lroot.substr.endIndex+1);
   
   
        int commonLen = CommonPrefix(prefix, k);
      //  System.out.print(" common len  = " +commonLen);
  
        if (commonLen > 0) {
          System.out.print(" , key = " + k );
          
          if (commonLen ==   prefix.length()) { 
            // System.out.print("\nfull prefix match found in key\n"); // full prefix match found in key
             k = k.substring(prefix.length());
           //  System.out.print(" , remain = " + k );  
             
            // [ add remain (k) to current node- as child or sibling to childs ] , give node, k
             buildTrieRecurse(Lroot ,k, allWords, indx );  
             return Lroot;  // found : no need to process siblings at this level
          }
          
          else if (commonLen ==   k.length()) { 
            // System.out.print("\nfull key match found prefix\n");// full key match found prefix
              Lroot.substr.startIndex = (short) ( allWords[Lroot.substr.wordIndex].indexOf(k) ) ;
              Lroot.substr.endIndex =  (short) (allWords[Lroot.substr.wordIndex].indexOf(k) +  k.length()-1 )  ;
              int lastIndx= Lroot.substr.wordIndex;
              Lroot.substr.wordIndex = indx;
             k = prefix.substring(k.length());
           //  System.out.print(" , remain = " + k ); 
  

                              
             // replace current node string to key, [ add remain (k) to current node- as child or sibling to childs, give node, k ]                                
              buildTrieRecurse(Lroot ,k, allWords, lastIndx);   
             return Lroot;  // found :no need to process siblings at this level
          }
          else { 
             // System.out.print("\npartial match\n"); // partial match
              j = k.substring(0,commonLen);
             // System.out.print(" , common  = " + j ); 
   
            
              Lroot.substr.endIndex =  (short)  (  Lroot.substr.startIndex +   j.length() -1  ); // keep same start, just change end
 
 
            
              k = k.substring(commonLen);
         //     System.out.print(" , pr 1 = " + k );     
              buildTrieRecurse(Lroot  ,k, allWords, indx);  
            
              k = prefix.substring(commonLen);
            //  System.out.print(" , pr 2 = " + k );     
              buildTrieRecurse(Lroot  ,k, allWords,  Lroot.substr.wordIndex ); 
            
               // replace current node string to common, [ add remain ( 2 k 's ) to current node- as child or sibling to childs , give node, k - call twice for each ]    
              return Lroot;  // found :no need to process siblings at this level
          }
         
 
        
      }
           prevRoot=Lroot; sibling=true;      
          Lroot = Lroot.sibling;
   }  // while loop end - process all siblings
   
   
  // if reached here  match not found in any child or siblings of root, insert that new node here
   
     // you found where to insert the new node.
   
                   System.out.print(" add to this root as child or sibling : " + k+"\n" ); // return from recusrsion
      		       short startIndex ;   short endIndex; 

                     
                   startIndex = (short)  ( allWords[indx].lastIndexOf(k) ) ;
                   endIndex =  (short) ( allWords[indx].lastIndexOf(k) +  k.length()-1 ) ;
                    
 
                  Indexes index1 = new Indexes(indx, startIndex, endIndex );
                  TrieNode newNode = new TrieNode(index1, null, null) ;
      
   // insert to Lroot - either firstChild or sibling - depending where null was found
                   
                    if (sibling)
                      prevRoot.sibling  = newNode;
                    else   
                      prevRoot.firstChild  = newNode;
   
   // Trie.print( root, allWords);
                    return Lroot;
       
   
   
}
  
  
        /**
     * @param str1
     * @param str2
     * @return the length of the longest common prefix
     */
    private static int   CommonPrefix(String str1, String str2) {
      int m = Math.min(str1.length(), str2.length());
      for (int i = 0; i < m; i++) {
        if (str1.charAt(i) != str2.charAt(i)) {
          return i;
        }
      }
     
      return m;
    }
  
	
	/**
	 * Given a trie, returns the "completion list" for a prefix, i.e. all the leaf nodes in the 
	 * trie whose words start with this prefix. 
	 * For instance, if the trie had the words "bear", "bull", "stock", and "bell",
	 * the completion list for prefix "b" would be the leaf nodes that hold "bear", "bull", and "bell"; 
	 * for prefix "be", the completion would be the leaf nodes that hold "bear" and "bell", 
	 * and for prefix "bell", completion would be the leaf node that holds "bell". 
	 * (The last example shows that an input prefix can be an entire word.) 
	 * The order of returned leaf nodes DOES NOT MATTER. So, for prefix "be",
	 * the returned list of leaf nodes can be either hold [bear,bell] or [bell,bear].
	 *
	 * @param root Root of Trie that stores all words to search on for completion lists
	 * @param allWords Array of words that have been inserted into the trie
	 * @param prefix Prefix to be completed with words in trie
	 * @return List of all leaf nodes in trie that hold words that start with the prefix, 
	 * 			order of leaf nodes does not matter.
	 *         If there is no word in the tree that has this prefix, null is returned.
	 */


 	public static ArrayList<TrieNode> completionList(TrieNode root,
										String[] allWords, String prefix) {
		/** COMPLETE THIS METHOD **/
		
		// FOLLOWING LINE IS A PLACEHOLDER TO ENSURE COMPILATION
		// MODIFY IT AS NEEDED FOR YOUR IMPLEMENTATION
 
        String pre ="";
        
        ArrayList<TrieNode> matches = new ArrayList<TrieNode>();
      
       TrieNode NodeFound = findPrefixRecur(  root, allWords,   prefix);
         if (NodeFound  != null) 
         {   pre = allWords[NodeFound.substr.wordIndex].substring(0, NodeFound.substr.endIndex+1);
           // System.out.println("FOUND : " + pre);
           
           
           findPrefixLeafs(  NodeFound ,allWords,matches);
           
         }
        
		 return matches;
	}
 
 
	
    private static   TrieNode findPrefixLeafs(TrieNode root, String[] allWords,ArrayList<TrieNode> matches ) {
 
      String pre ="";
 
		if (root == null) {
			return null;
		}
 
            if (root.firstChild == null) { // last node     
                 pre = allWords[root.substr.wordIndex].substring(0, root.substr.endIndex+1);
                 // System.out.print( " , " + pre);
                 matches.add(root); 
               } 
           else {
		    for (TrieNode ptr=root.firstChild; ptr != null; ptr=ptr.sibling) {
                  if (ptr.firstChild != null) {
                    findPrefixLeafs(ptr , allWords,matches ) ; 
                  }
                else
                 {  
                   pre = allWords[ptr.substr.wordIndex].substring(0, ptr.substr.endIndex+1);
                   // System.out.print( " , " + pre);
                   matches.add(ptr); 
                } 
            }  
		}
    
      return null;
	}
  
  
  
  
  private static  TrieNode  findPrefixRecur(TrieNode root,
										String[] allWords, String prefix) {
 
      TrieNode nodefound = null;
    String pre ="";
		if (root == null) {
			return null;
		}
 
		
		if (root.substr != null) {
			  pre = allWords[root.substr.wordIndex]
							.substring(0, root.substr.endIndex+1);
			if ( pre.matches(prefix +"(.*)" ))  return root;
		}
		
 
			//System.out.println(root.substr ); System.out.print( " : " + pre);
 
		
		for (TrieNode ptr=root.firstChild; ptr != null; ptr=ptr.sibling) {
 
			nodefound = findPrefixRecur(ptr, allWords, prefix) ; 
            if( nodefound !=null )
               {  
               
               break;
               }  
		}
    
    return nodefound;
	}
  
  
	
	private static void print(TrieNode root, int indent, String[] words) {
		if (root == null) {
			return;
		}
		for (int i=0; i < indent-1; i++) {
			System.out.print("    ");
		}
		
		if (root.substr != null) {
			String pre = words[root.substr.wordIndex]
							.substring(0, root.substr.endIndex+1);
			System.out.println("      " + pre);
		}
		
		for (int i=0; i < indent-1; i++) {
			System.out.print("    ");
		}
		System.out.print(" ---");
		if (root.substr == null) {
			System.out.println("root");
		} else {
			System.out.println(root.substr);
		}
		
		for (TrieNode ptr=root.firstChild; ptr != null; ptr=ptr.sibling) {
			for (int i=0; i < indent-1; i++) {
				System.out.print("    ");
			}
			System.out.println("     |");
			print(ptr, indent+1, words);
		}
	}
 }
