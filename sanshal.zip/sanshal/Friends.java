package friends;

import structures.Queue;
import structures.Stack;

import java.util.*;


public class Friends {

  	// all the members in the graph
	private static Person[] members;
	
	// hash map to store the (name,num) association
	private static HashMap<String,Integer> map;
  
  
     private static String nameForIndex(int index){
		return members[index].name;
	}
	
	private static int indexForName(String name){
		try{
			return map.get(name);
		}catch(Exception NullPointerException){
			return -1;
		}
	}
  
  
	/**
	 * Finds the shortest chain of people from p1 to p2.
	 * Chain is returned as a sequence of names starting with p1,
	 * and ending with p2. Each pair (n1,n2) of consecutive names in
	 * the returned chain is an edge in the graph.
	 * 
	 * @param g Graph for which shortest chain is to be found.
	 * @param p1 Person with whom the chain originates
	 * @param p2 Person at whom the chain terminates
	 * @return The shortest chain from p1 to p2. Null if there is no
	 *         path from p1 to p2
	 */
	public static ArrayList<String> shortestChain(Graph g, String p1, String p2) {
		
		/** COMPLETE THIS METHOD **/
		
		// FOLLOWING LINE IS A PLACEHOLDER TO MAKE COMPILER HAPPY
		// CHANGE AS REQUIRED FOR YOUR IMPLEMENTATION
        members = g.members;  map = g.map;
      
       if(indexForName(p1) == -1 || indexForName(p2) == -1){
			System.out.println("invalid name!");
			return null;
		}
      
		Stack<String> chain = new Stack<String>();
		int snum = indexForName(p1);
      
		Person start = members[snum];
		Person end = members[indexForName(p2)];
        return shortest(start, end);
      
 
	}
	
  
  
  	private static ArrayList<String> shortest(Person origin, Person target)
	{
		ArrayList<Person> unvisited = new ArrayList<Person>();
		ArrayList<Person> q = new ArrayList<Person>();
		ArrayList<Person> path = new ArrayList<Person>();
		HashMap<Person, Integer> distances = new HashMap<Person, Integer>();
		HashMap<Person, Person> previous = new HashMap<Person, Person>();

      ArrayList<String> returnAlist = new ArrayList<String>();
      
       for ( int key=0; key < members.length; key++)
		{
			unvisited.add(members[key] );
			distances.put(members[key], -1);
			previous.put(members[key], null);
		}

      
		Person current = origin;
		unvisited.remove(current);
		distances.put(current, 0);

		while ((!q.isEmpty()) || (!unvisited.isEmpty()))
		{
 
         
 		for (Friend e=current.first; e != null; e=e.next) {
			 
				Person p =  members[e.fnum] ;
				 if (unvisited.contains(p))
				{
					unvisited.remove(p);
					q.add(p);
					distances.put(p, distances.get(current)+1);
					previous.put(p, current);
				}		 
			 
		}
            
          
          
          

			if (!q.isEmpty())
				current = q.remove(0);
			else if (!unvisited.isEmpty())
				break;
		}

		if (distances.get(target) == -1)
		{
			System.out.println("\nno path from " + origin.name + " to " + target.name + ".");
			return null;
		}

		else if (distances.get(target) == 0)
		{
			System.out.println("\n  friends with same .");
			return null;
		}

		else
		{
			//System.out.println("\n   shortest path from " + origin.name + " to " + target.name + "  : ");
		}

		path.add(target);
		while (target != origin)
		{
			target = previous.get(target);
			path.add(0, target);
		}

		//System.out.print(path.remove(0).name);
      returnAlist.add(path.remove(0).name);
		for (Person p : path)
        { //System.out.print(" --> "+p.name);  
         returnAlist.add(p.name); }

		 
      
        return returnAlist ; // return path;
      
 
	}
   
  
	/**
	 * Finds all cliques of students in a given school.
	 * 
	 * Returns an array list of array lists - each constituent array list contains
	 * the names of all students in a clique.
	 * 
	 * @param g Graph for which cliques are to be found.
	 * @param school Name of school
	 * @return Array list of clique array lists. Null if there is no student in the
	 *         given school
	 */
	public static ArrayList<ArrayList<String>> cliques(Graph g, String school) {
		
		/** COMPLETE THIS METHOD **/
		
		// FOLLOWING LINE IS A PLACEHOLDER TO MAKE COMPILER HAPPY
		// CHANGE AS REQUIRED FOR YOUR IMPLEMENTATION
      
        members = g.members;  map = g.map;
        ArrayList<ArrayList<String>> returnAlist = new  ArrayList<ArrayList<String>>();  
      
    	 ArrayList<Person> unvisited = new ArrayList<Person>();
		ArrayList<Person> clique = new ArrayList<Person>();
		ArrayList<Person> q = new ArrayList<Person>();

 
      
      	if (school != null)
		{
			 for ( int key=0; key < members.length; key++)
				if (school.equals(members[key].school))
					unvisited.add(members[key]);
		}
		else
		{
			for ( int key=0; key < members.length; key++)
				if (members[key].school == null)
					unvisited.add(members[key]);
		} 

      
		int count = 1;
		Person current = null;

		if (school == null)
			System.out.println("These are the cliques for people without school: ");

		while (!unvisited.isEmpty())
		{
			q.add(unvisited.remove(0));
			clique.add(q.get(0));  

			while (!q.isEmpty())
			{
				if (!q.isEmpty())
					current = q.remove(0);

 
             for (Friend e=current.first; e != null; e=e.next) {
			 
				Person p =  members[e.fnum] ;
					if (unvisited.contains(p))
					{
						unvisited.remove(p);
						clique.add(p);  
						q.add(p);
					}
				}                  
			}

            ArrayList<String> inner = new ArrayList<String>();  
          
         //   System.out.print("\nClique " + count + ": ");
            for (Person p : clique)
            {  //System.out.println(p.name );   
              inner.add(p.name) ;}
          
             returnAlist.add(inner);
                
          
			clique.clear();
			count++;
		}  
      
      		return returnAlist ; //return clique;
 
		
	}
	
	/**
	 * Finds and returns all connectors in the graph.
	 * 
	 * @param g Graph for which connectors needs to be found.
	 * @return Names of all connectors. Null if there are no connectors.
	 */
	public static ArrayList<String> connectors(Graph g) {
		
		/** COMPLETE THIS METHOD **/
		
		// FOLLOWING LINE IS A PLACEHOLDER TO MAKE COMPILER HAPPY
		// CHANGE AS REQUIRED FOR YOUR IMPLEMENTATION
              members = g.members;  map = g.map;
      
           
            ArrayList<String> returnAlist = new ArrayList<String>();
      		ArrayList<Person> connectors = new ArrayList<Person>();

 
       for ( int key1=0; key1 < members.length; key1++)
		{   String poop = members[key1].name;
			ArrayList<Person> unvisited = new ArrayList<Person>();
			ArrayList<Person> q = new ArrayList<Person>();

 
 
          
           for ( int key2=0; key2 < members.length; key2++)
             unvisited.add(members[key2] );
           
			Person origin = members[key1] ; // graph.get(poop);   // get this person
			Person current = origin;

			unvisited.remove(current);

			while ((!q.isEmpty()) || (!unvisited.isEmpty()))
			{
                 for (Friend e=current.first; e != null; e=e.next) {
			 
				   Person p =  members[e.fnum] ;
					if (unvisited.contains(p))
					{
						unvisited.remove(p);
						q.add(p);
					}
				}

				if (!q.isEmpty())
					current = q.remove(0);
				else if (!unvisited.isEmpty())
					break;
			}

			int personCount = unvisited.size();
          
           for ( int key=0; key < members.length; key++)
 
			{
				unvisited.clear();
				q.clear();

                for ( int key3=0; key3 < members.length; key3++)
                   unvisited.add(members[key3] );
              
				current = origin;
				Person notAllowed = members[key]; // graph.get(no);

				unvisited.remove(current);
				unvisited.remove(notAllowed);

				while ((!q.isEmpty()) || (!unvisited.isEmpty()))
				{
                 for (Friend e=current.first; e != null; e=e.next) {
			 
				      Person p =  members[e.fnum] ;
						if (unvisited.contains(p))
						{
							unvisited.remove(p);
							q.add(p);
						}
					}

					if (!q.isEmpty())
						current = q.remove(0);
					else if (!unvisited.isEmpty())
						break;
				}

				if (unvisited.size() > personCount)
					if (!connectors.contains(notAllowed))
						connectors.add(notAllowed);

 
			}
		}
 
		//System.out.println("\nThe Connectors in this graph are: ");
		//System.out.print(connectors.remove(0).name);
         returnAlist.add(connectors.remove(0).name); 
		for (Person p : connectors)
        { //System.out.print(", " + p.name); 
          returnAlist.add(p.name); }
		
      
       
		return returnAlist ; //return connectors;
		
	}
}